function populate(form)
{
form.options.length = 0;
form.options[0] = new Option("Select a county of New Jersey","");
form.options[1] = new Option("Atlantic County","Atlantic County");
form.options[2] = new Option("Bergen County","Bergen County");
form.options[3] = new Option("Burlington County","Burlington County");
form.options[4] = new Option("Camden County","Camden County");
form.options[5] = new Option("Cape May County","Cape May County");
form.options[6] = new Option("Cumberland County","Cumberland County");
form.options[7] = new Option("Essex County","Essex County");
form.options[8] = new Option("Gloucester County","Gloucester County");
form.options[9] = new Option("Hudson County","Hudson County");
form.options[10] = new Option("Hunterdon County","Hunterdon County");
form.options[11] = new Option("Mercer County","Mercer County");
form.options[12] = new Option("Middlesex County","Middlesex County");
form.options[13] = new Option("Monmouth County","Monmouth County");
form.options[14] = new Option("Morris County","Morris County");
form.options[15] = new Option("Ocean County","Ocean County");
form.options[16] = new Option("Passaic County","Passaic County");
form.options[17] = new Option("Salem County","Salem County");
form.options[18] = new Option("Somerset County","Somerset County");
form.options[19] = new Option("Sussex County","Sussex County");
form.options[20] = new Option("Union County","Union County");
form.options[21] = new Option("Warren County","Warren County");
}