function populate(form)
{
form.options.length = 0;
form.options[0] = new Option("Select a county of New Mexico","");
form.options[1] = new Option("Bernalillo County","Bernalillo County");
form.options[2] = new Option("Catron County","Catron County");
form.options[3] = new Option("Chaves County","Chaves County");
form.options[4] = new Option("Cibola County","Cibola County");
form.options[5] = new Option("Colfax County","Colfax County");
form.options[6] = new Option("Curry County","Curry County");
form.options[7] = new Option("De Baca County","De Baca County");
form.options[8] = new Option("Doña Ana County","Doña Ana County");
form.options[9] = new Option("Eddy County","Eddy County");
form.options[10] = new Option("Grant County","Grant County");
form.options[11] = new Option("Guadalupe County","Guadalupe County");
form.options[12] = new Option("Harding County","Harding County");
form.options[13] = new Option("Hidalgo County","Hidalgo County");
form.options[14] = new Option("Lea County","Lea County");
form.options[15] = new Option("Lincoln County","Lincoln County");
form.options[16] = new Option("Los Alamos County","Los Alamos County");
form.options[17] = new Option("Luna County","Luna County");
form.options[18] = new Option("McKinley County","McKinley County");
form.options[19] = new Option("Mora County","Mora County");
form.options[20] = new Option("Otero County","Otero County");
form.options[21] = new Option("Quay County","Quay County");
form.options[22] = new Option("Rio Arriba County","Rio Arriba County");
form.options[23] = new Option("Roosevelt County","Roosevelt County");
form.options[24] = new Option("Sandoval County","Sandoval County");
form.options[25] = new Option("San Juan County","San Juan County");
form.options[26] = new Option("San Miguel County","San Miguel County");
form.options[27] = new Option("Santa Fe County","Santa Fe County");
form.options[28] = new Option("Sierra County","Sierra County");
form.options[29] = new Option("Socorro County","Socorro County");
form.options[30] = new Option("Taos County","Taos County");
form.options[31] = new Option("Torrance County","Torrance County");
form.options[32] = new Option("Union County","Union County");
form.options[33] = new Option("Valencia County","Valencia County");
}