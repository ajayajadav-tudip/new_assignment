function populate(form)
{
form.options.length = 0;
form.options[0] = new Option("Select a county of Rhode Island","");
form.options[1] = new Option("Bristol County","Bristol County");
form.options[2] = new Option("Kent County","Kent County");
form.options[3] = new Option("Newport County","Newport County");
form.options[4] = new Option("Providence County","Providence County");
form.options[5] = new Option("Washington County","Washington County");
}