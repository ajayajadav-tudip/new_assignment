function populate(form)
{
form.options.length = 0;
form.options[0] = new Option("Select a county of Wyoming","");
form.options[1] = new Option("Albany County","Albany County");
form.options[2] = new Option("Big Horn County","Big Horn County");
form.options[3] = new Option("Campbell County","Campbell County");
form.options[4] = new Option("Carbon County","Carbon County");
form.options[5] = new Option("Converse County","Converse County");
form.options[6] = new Option("Crook County","Crook County");
form.options[7] = new Option("Fremont County","Fremont County");
form.options[8] = new Option("Goshen County","Goshen County");
form.options[9] = new Option("Hot Springs County","Hot Springs County");
form.options[10] = new Option("Johnson County","Johnson County");
form.options[11] = new Option("Laramie County","Laramie County");
form.options[12] = new Option("Lincoln County","Lincoln County");
form.options[13] = new Option("Natrona County","Natrona County");
form.options[14] = new Option("Niobrara County","Niobrara County");
form.options[15] = new Option("Park County","Park County");
form.options[16] = new Option("Platte County","Platte County");
form.options[17] = new Option("Sheridan County","Sheridan County");
form.options[18] = new Option("Sublette County","Sublette County");
form.options[19] = new Option("Sweetwater County","Sweetwater County");
form.options[20] = new Option("Teton County","Teton County");
form.options[21] = new Option("Uinta County","Uinta County");
form.options[22] = new Option("Washakie County","Washakie County");
form.options[23] = new Option("Weston County","Weston County");
}