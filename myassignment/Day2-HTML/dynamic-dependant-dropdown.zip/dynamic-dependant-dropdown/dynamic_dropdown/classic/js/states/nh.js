function populate(form)
{
form.options.length = 0;
form.options[0] = new Option("Select a county of New Hampshire","");
form.options[1] = new Option("Belknap County","Belknap County");
form.options[2] = new Option("Carroll County","Carroll County");
form.options[3] = new Option("Cheshire County","Cheshire County");
form.options[4] = new Option("Coos County","Coos County");
form.options[5] = new Option("Grafton County","Grafton County");
form.options[6] = new Option("Hillsborough County","Hillsborough County");
form.options[7] = new Option("Merrimack County","Merrimack County");
form.options[8] = new Option("Rockingham County","Rockingham County");
form.options[9] = new Option("Strafford County","Strafford County");
form.options[10] = new Option("Sullivan County","Sullivan County");
}