function populate(form)
{
form.options.length = 0;
form.options[0] = new Option("Select a county of Nevada","");
form.options[1] = new Option("Carson City","Carson City");
form.options[2] = new Option("Churchill County","Churchill County");
form.options[3] = new Option("Clark County","Clark County");
form.options[4] = new Option("Douglas County","Douglas County");
form.options[5] = new Option("Elko County","Elko County");
form.options[6] = new Option("Esmeralda County","Esmeralda County");
form.options[7] = new Option("Eureka County","Eureka County");
form.options[8] = new Option("Humboldt County","Humboldt County");
form.options[9] = new Option("Lander County","Lander County");
form.options[10] = new Option("Lincoln County","Lincoln County");
form.options[11] = new Option("Lyon County","Lyon County");
form.options[12] = new Option("Mineral County","Mineral County");
form.options[13] = new Option("Nye County","Nye County");
form.options[14] = new Option("Pershing County","Pershing County");
form.options[15] = new Option("Storey County","Storey County");
form.options[16] = new Option("Washoe County","Washoe County");
form.options[17] = new Option("White Pine County","White Pine County");
}