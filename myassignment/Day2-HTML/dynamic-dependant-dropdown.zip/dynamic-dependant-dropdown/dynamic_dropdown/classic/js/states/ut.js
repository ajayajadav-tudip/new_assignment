function populate(form)
{
form.options.length = 0;
form.options[0] = new Option("Select a county of Utah","");
form.options[1] = new Option("Beaver County","Beaver County");
form.options[2] = new Option("Box Elder County","Box Elder County");
form.options[3] = new Option("Cache County","Cache County");
form.options[4] = new Option("Carbon County","Carbon County");
form.options[5] = new Option("Daggett County","Daggett County");
form.options[6] = new Option("Davis County","Davis County");
form.options[7] = new Option("Duchesne County","Duchesne County");
form.options[8] = new Option("Emery County","Emery County");
form.options[9] = new Option("Garfield County","Garfield County");
form.options[10] = new Option("Grand County","Grand County");
form.options[11] = new Option("Iron County","Iron County");
form.options[12] = new Option("Juab County","Juab County");
form.options[13] = new Option("Kane County","Kane County");
form.options[14] = new Option("Millard County","Millard County");
form.options[15] = new Option("Morgan County","Morgan County");
form.options[16] = new Option("Piute County","Piute County");
form.options[17] = new Option("Rich County","Rich County");
form.options[18] = new Option("Salt Lake County","Salt Lake County");
form.options[19] = new Option("San Juan County","San Juan County");
form.options[20] = new Option("Sanpete County","Sanpete County");
form.options[21] = new Option("Sevier County","Sevier County");
form.options[22] = new Option("Summit County","Summit County");
form.options[23] = new Option("Tooele County","Tooele County");
form.options[24] = new Option("Uintah County","Uintah County");
form.options[25] = new Option("Utah County","Utah County");
form.options[26] = new Option("Wasatch County","Wasatch County");
form.options[27] = new Option("Washington County","Washington County");
form.options[28] = new Option("Wayne County","Wayne County");
form.options[29] = new Option("Weber County","Weber County");
}