function populate(form)
{
form.options.length = 0;
form.options[0] = new Option("Select a county of Delaware","");
form.options[1] = new Option("Kent County","Kent County");
form.options[2] = new Option("New Castle County","New Castle County");
form.options[3] = new Option("Sussex County","Sussex County");
}